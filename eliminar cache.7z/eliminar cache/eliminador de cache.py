import os
import shutil
import sys
import threading
import schedule
import time
import psutil
import tkinter as tk
from tkinter import messagebox, ttk
from datetime import datetime
from PIL import Image, ImageTk

# ---------------------- FUNCIONES DE LIMPIEZA ---------------------- #
def obtener_tamano(path):
    total = 0
    if os.path.isfile(path):
        return os.path.getsize(path)
    for dirpath, dirnames, filenames in os.walk(path):
        for f in filenames:
            try:
                fp = os.path.join(dirpath, f)
                total += os.path.getsize(fp)
            except:
                pass
    return total

def eliminar_directorio(path):
    try:
        if os.path.exists(path):
            tam = obtener_tamano(path)
            shutil.rmtree(path)
            return tam, f"✔ Eliminado: {path}\n"
        else:
            return 0, f"✘ No encontrado: {path}\n"
    except Exception as e:
        return 0, f"⚠ Error eliminando {path}: {e}\n"

def eliminar_archivo(path):
    try:
        if os.path.exists(path):
            tam = os.path.getsize(path)
            os.remove(path)
            return tam, f"✔ Eliminado: {path}\n"
        else:
            return 0, f"✘ No encontrado: {path}\n"
    except Exception as e:
        return 0, f"⚠ Error eliminando archivo: {e}\n"

def eliminar_cache_navegadores(seleccion):
    resultado = "\n🧹 Caché de navegadores:\n"
    total = 0
    local = os.environ.get("LOCALAPPDATA")
    appdata = os.environ.get("APPDATA")

    perfiles = {
        "Chrome": os.path.join(local, "Google", "Chrome", "User Data"),
        "Edge": os.path.join(local, "Microsoft", "Edge", "User Data"),
        "Brave": os.path.join(local, "BraveSoftware", "Brave-Browser", "User Data"),
        "Opera": os.path.join(local, "Opera Software", "Opera Stable"),
        "Firefox": os.path.join(appdata, "Mozilla", "Firefox", "Profiles")
    }

    for navegador in seleccion:
        if navegador == "Firefox":
            perfiles_dir = perfiles["Firefox"]
            if os.path.exists(perfiles_dir):
                for perfil in os.listdir(perfiles_dir):
                    cache_path = os.path.join(perfiles_dir, perfil, "cache2")
                    tam, res = eliminar_directorio(cache_path)
                    total += tam
                    resultado += res
            else:
                resultado += "⚠ No se encontró carpeta de perfiles de Firefox\n"

        elif navegador in ["Chrome", "Edge", "Brave"]:
            base = perfiles[navegador]
            if os.path.exists(base):
                for perfil in os.listdir(base):
                    cache_path = os.path.join(base, perfil, "Cache")
                    if os.path.exists(cache_path):
                        tam, res = eliminar_directorio(cache_path)
                        total += tam
                        resultado += res
            else:
                resultado += f"⚠ Carpeta no encontrada para {navegador}\n"

        elif navegador == "Opera":
            cache_path = os.path.join(perfiles["Opera"], "Cache")
            tam, res = eliminar_directorio(cache_path)
            total += tam
            resultado += res

        else:
            resultado += f"⚠ {navegador} no soportado\n"

    return total, resultado

def eliminar_historial_y_cookies():
    resultado = "\n📑 Historial y cookies:\n"
    # Aquí puedes implementar limpieza real si lo deseas
    return 0, resultado + "✔ Historial y cookies limpiados (simulado).\n"

def limpiar_papelera():
    resultado = "\n🗑 Papelera:\n"
    try:
        import winshell
        winshell.recycle_bin().empty(confirm=False, show_progress=False, sound=False)
        return 0, resultado + "✔ Papelera vaciada.\n"
    except ImportError:
        return 0, resultado + "❌ Instala winshell: pip install winshell\n"

def limpiar_temporales():
    resultado = "\n🧊 Temporales:\n"
    total = 0
    temp_paths = [os.environ.get("TEMP"), os.environ.get("TMP")]
    for path in temp_paths:
        tam, res = eliminar_directorio(path)
        total += tam
        resultado += res
    return total, resultado

def limpiar_ram():
    resultado = "\n🧠 Memoria RAM:\n"
    cerrados = 0
    for proc in psutil.process_iter(['pid', 'name', 'memory_info']):
        try:
            mem_mb = proc.info['memory_info'].rss / (1024 * 1024)
            if mem_mb > 200 and proc.info['name'].lower() not in ['explorer.exe', 'python.exe']:
                proc.terminate()
                cerrados += 1
        except:
            continue
    return 0, resultado + f"✔ Procesos finalizados: {cerrados}\n"

def guardar_historial(texto):
    with open("historial_limpiezas.txt", "a", encoding="utf-8") as f:
        f.write(f"\n=== Limpieza: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===\n")
        f.write(texto)

# ---------------------- FUNCIONES PROGRAMADAS ---------------------- #
def limpieza_programada():
    try:
        seleccionados = [nav for nav, var in navegadores_vars.items() if var.get() == 1]
    except:
        seleccionados = ["Chrome", "Edge", "Firefox", "Opera", "Brave"]

    if seleccionados:
        eliminar_cache_navegadores(seleccionados)
        eliminar_historial_y_cookies()
        limpiar_papelera()
        limpiar_temporales()
        limpiar_ram()

def iniciar_scheduler():
    schedule.every().day.at("10:00").do(limpieza_programada)
    while True:
        schedule.run_pending()
        time.sleep(60)

# ---------------------- INTERFAZ CONSOLA ---------------------- #
if "--limpiar" in sys.argv:
    navegadores = []
    for nav in ["chrome", "edge", "firefox", "opera", "brave"]:
        if f"--{nav}" in sys.argv:
            navegadores.append(nav.capitalize())

    if navegadores:
        print("Iniciando limpieza por consola...")
        total, resultado = eliminar_cache_navegadores(navegadores)
        _, r2 = eliminar_historial_y_cookies()
        _, r3 = limpiar_papelera()
        _, r4 = limpiar_temporales()
        _, r5 = limpiar_ram()
        resultado += r2 + r3 + r4 + r5
        espacio = total / (1024 * 1024)
        resultado += f"\n💾 Espacio liberado: {espacio:.2f} MB"
        guardar_historial(resultado)
        print(resultado)
        sys.exit()
# ---------------------- MODO MINI FLOTANTE ---------------------- #
def abrir_modo_mini():
    mini = tk.Toplevel()
    mini.title("Mini Limpiador")
    mini.geometry("100x100")
    mini.overrideredirect(True)  # Quita los bordes
    mini.wm_attributes("-topmost", True)  # Siempre visible
    mini.configure(bg="#2e86de")

    # Permitir mover la ventana mini arrastrándola
    def start_move(event):
        mini.x = event.x
        mini.y = event.y

    def do_move(event):
        dx = event.x - mini.x
        dy = event.y - mini.y
        x = mini.winfo_x() + dx
        y = mini.winfo_y() + dy
        mini.geometry(f"+{x}+{y}")

    mini.bind("<ButtonPress-1>", start_move)
    mini.bind("<B1-Motion>", do_move)

    # Tooltip flotante
    tooltip = tk.Label(mini, text="Iniciar limpieza", bg="black", fg="white", font=("Segoe UI", 8), padx=5, pady=2)
    tooltip.place_forget()

    def mostrar_tooltip(event):
        tooltip.place(x=event.x + 10, y=event.y + 10)

    def ocultar_tooltip(event):
        tooltip.place_forget()

    # Botón de limpieza
    boton_mini = tk.Button(mini, text="🧹", font=("Segoe UI", 22), bg="white", fg="#2e86de",
                           relief="flat", command=ejecutar_limpieza, cursor="hand2")
    boton_mini.pack(expand=True, fill="both", padx=10, pady=10)

    boton_mini.bind("<Enter>", mostrar_tooltip)
    boton_mini.bind("<Leave>", ocultar_tooltip)

    # Botón de cerrar
    btn_cerrar = tk.Button(mini, text="❌", bg="#2e86de", fg="white", bd=0,
                           font=("Segoe UI", 9), command=mini.destroy, cursor="hand2")
    btn_cerrar.place(x=75, y=0, width=25, height=25)


# ---------------------- INTERFAZ GRÁFICA ---------------------- #
ventana = tk.Tk()
ventana.title("🧼 Limpiador")
ventana.geometry("500x530")
ventana.configure(bg="#f2f4f8")

def cargar_icono(ruta, tamano=(24, 24)):
    try:
        imagen = Image.open(ruta)
        imagen = imagen.resize(tamano, Image.Resampling.LANCZOS)
        return ImageTk.PhotoImage(imagen)
    except Exception as e:
        print(f"Error cargando ícono {ruta}: {e}")
        return None

idioma = tk.StringVar(value="es")
textos = {
    "es": {
        "titulo": "🧼 Limpiador de Sistema Profesional",
        "boton": "🧹 Iniciar limpieza",
        "tema": "Tema",
        "resultado": "Resultado de limpieza",
        "aviso": "Selecciona al menos un navegador para limpiar.",
        "pie": "© 2025 Herramienta de Mantenimiento"
    },
    "en": {
        "titulo": "🧼 Professional System Cleaner",
        "boton": "🧹 Start Cleaning",
        "tema": "Theme",
        "resultado": "Cleaning Result",
        "aviso": "Please select at least one browser to clean.",
        "pie": "© 2025 Maintenance Tool"
    },
    "pt": {
        "titulo": "🧼 Limpador de Sistema Profissional",
        "boton": "🧹 Iniciar limpeza",
        "tema": "Tema",
        "resultado": "Resultado da limpeza",
        "aviso": "Selecione pelo menos um navegador para limpar.",
        "pie": "© 2025 Ferramenta de Manutenção"
    }
}

def aplicar_tema():
    color_bg = "#2e2e2e" if tema.get() == "oscuro" else "#f2f4f8"
    color_fg = "white" if tema.get() == "oscuro" else "black"
    color_title = "white" if tema.get() == "oscuro" else "#2e86de"
    color_footer = "#ccc" if tema.get() == "oscuro" else "#999"

    ventana.configure(bg=color_bg)
    etiqueta.config(bg=color_bg, fg=color_title)
    pie.config(bg=color_bg, fg=color_footer)
    frame_navegadores.config(bg=color_bg)
    for widget in frame_navegadores.winfo_children():
        widget.config(bg=color_bg, fg=color_fg)
    idioma_frame.config(bg=color_bg)
    tema_label.config(bg=color_bg, fg=color_fg)

def aplicar_idioma():
    lang = idioma.get()
    etiqueta.config(text=textos[lang]["titulo"])
    boton.config(text=textos[lang]["boton"])
    pie.config(text=textos[lang]["pie"])
    tema_label.config(text=textos[lang]["tema"])

def ejecutar_limpieza():
    seleccionados = [nav for nav, var in navegadores_vars.items() if var.get() == 1]
    if not seleccionados:
        messagebox.showwarning("Aviso", textos[idioma.get()]["aviso"])
        return

    barra['value'] = 0
    ventana.update_idletasks()

    total_liberado = 0
    resultado = "Limpieza en curso...\n"

    l1, r1 = eliminar_cache_navegadores(seleccionados)
    total_liberado += l1
    resultado += r1
    barra['value'] = 20

    l2, r2 = eliminar_historial_y_cookies()
    total_liberado += l2
    resultado += r2
    barra['value'] = 40

    l3, r3 = limpiar_papelera()
    total_liberado += l3
    resultado += r3
    barra['value'] = 60

    l4, r4 = limpiar_temporales()
    total_liberado += l4
    resultado += r4
    barra['value'] = 80

    l5, r5 = limpiar_ram()
    total_liberado += l5
    resultado += r5
    barra['value'] = 100

    espacio = total_liberado / (1024 * 1024)
    resultado += f"\n💾 Espacio liberado: {espacio:.2f} MB"

    guardar_historial(resultado)
    messagebox.showinfo(textos[idioma.get()]["resultado"], resultado)

def mostrar_historial():
    try:
        with open("historial_limpiezas.txt", "r", encoding="utf-8") as f:
            contenido = f.read()
            messagebox.showinfo("Historial", contenido if contenido else "No hay registros.")
    except:
        messagebox.showerror("Error", "No se pudo leer historial.")

def mostrar_ayuda():
    messagebox.showinfo("Ayuda rápida", "🔹 Ctrl+L: Iniciar limpieza\n🔹 Ctrl+H: Ver historial\n🔹 F1: Ayuda\n🔹 Puedes usar consola con --limpiar")

etiqueta = tk.Label(ventana, text=textos["es"]["titulo"], bg="#f2f4f8", fg="#2e86de", font=("Segoe UI", 14, "bold"))
etiqueta.pack(pady=15)

barra = ttk.Progressbar(ventana, length=300, mode='determinate')
barra.pack(pady=10)

# Cargar iconos
chrome_img = cargar_icono("icono/Google.ico")
firefox_img = cargar_icono("icono/Firefox.ico")
edge_img = cargar_icono("icono/Edge.ico")
opera_img = cargar_icono("icono/Opera.ico")
brave_img = cargar_icono("icono/Brave.ico")

iconos_navegadores = {
    "Chrome": chrome_img,
    "Firefox": firefox_img,
    "Edge": edge_img,
    "Opera": opera_img,
    "Brave": brave_img
}

# Checkbuttons
navegadores_vars = {}
frame_navegadores = tk.Frame(ventana, bg="#f2f4f8")
frame_navegadores.pack(pady=5)

for navegador in ["Chrome", "Edge", "Firefox", "Opera", "Brave"]:
    var = tk.IntVar()
    chk = tk.Checkbutton(frame_navegadores, text=navegador, variable=var, image=iconos_navegadores.get(navegador),
                         compound="left", bg="#f2f4f8", font=("Segoe UI", 11), padx=10)
    chk.pack(anchor="center", pady=2)
    navegadores_vars[navegador] = var

# Botón principal
boton = tk.Button(ventana, text=textos["es"]["boton"], command=ejecutar_limpieza,
                  bg="#2e86de", fg="white", font=("Segoe UI", 12, "bold"),
                  padx=25, pady=10, bd=0, cursor="hand2")
boton.pack(pady=15)

# Idioma y tema
idioma_frame = tk.Frame(ventana, bg="#f2f4f8")
idioma_frame.pack(pady=5)

tk.Label(idioma_frame, text="Idioma:", bg="#f2f4f8").pack(side="left")
tk.OptionMenu(idioma_frame, idioma, "es", "en", "pt", command=lambda _: aplicar_idioma()).pack(side="left")

tema = tk.StringVar(value="claro")
tema_label = tk.Label(ventana, text=textos["es"]["tema"], bg="#f2f4f8")
tema_label.pack()
tk.OptionMenu(ventana, tema, "claro", "oscuro", command=lambda _: aplicar_tema()).pack()

ventana.bind("<Control-l>", lambda e: ejecutar_limpieza())
ventana.bind("<Control-h>", lambda e: mostrar_historial())
ventana.bind("<F1>", lambda e: mostrar_ayuda())


# Botón para abrir modo mini
btn_mini = tk.Button(ventana, text="🧊 Modo Mini", command=abrir_modo_mini,
                     bg="#ccc", fg="black", font=("Segoe UI", 10), relief="flat", cursor="hand2")
btn_mini.pack(pady=5)


pie = tk.Label(ventana, text=textos["es"]["pie"], bg="#f2f4f8", fg="#999", font=("Segoe UI", 9))
pie.pack(side="bottom", pady=10)

# Iniciar hilo del scheduler
threading.Thread(target=iniciar_scheduler, daemon=True).start()

ventana.mainloop()

